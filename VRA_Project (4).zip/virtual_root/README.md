# virtual_root
Step 4 (done in code, untested on device): guest-only su broker inside the Linux guest (`virtualization_engine/guest_init.sh`).
- Guest apps are users `app1`, `app2`. Each can write only to its own request FIFO, so identity comes from file permissions.
- `vsu -c cmd` asks the guest root daemon. Allowed only if the app is in `vra.su=` on the kernel command line, which VRA fills from the Root manager.
- Allow/deny events are sent back to VRA as `@@VRA_SU|...@@` console lines and shown in the access log.
- Policy store: `frontend/lib/root_policy.dart` (tested). Changes apply at the next guest start.
Limits: it is a Linux guest, not Android. `vsu` is not a setuid `su`.
