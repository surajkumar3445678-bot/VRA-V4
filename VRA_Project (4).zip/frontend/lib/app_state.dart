import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'compat.dart';
import 'console_feed.dart';
import 'host_bridge.dart';
import 'root_policy.dart';

class AppState extends ChangeNotifier {
  CompatReport? compat;
  Map<dynamic, dynamic> guest = {};
  String? bootMessage;
  String? qemuOutput;
  bool qemuBusy = false;
  String? kernelOutput;
  bool kernelBusy = false;
  bool linuxRunning = false;
  bool guestStarting = false;
  Map<String, String> guestStats = {};
  final ConsoleFeed console = ConsoleFeed();
  int _total = 0;
  bool _polling = false;
  Timer? _poller;
  DateTime _startedAt = DateTime.now();
  final RootPolicy root = RootPolicy();
  bool shareClipboard = false;
  bool shareFiles = false;
  bool onboarded = false;
  SharedPreferences? _p;

  bool get guestInstalled => guest['installed'] == true;
  // No guest launcher is implemented yet, so a guest is never reported running.
  bool get guestRunning => false;

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();
    _p = p;
    onboarded = p.getBool('onboarded') ?? false;
    shareClipboard = p.getBool('shareClipboard') ?? false;
    shareFiles = p.getBool('shareFiles') ?? false;
    final j = p.getString('rootPolicy');
    if (j != null) root.loadJson(jsonDecode(j));
    await refresh();
    _poller ??= Timer.periodic(const Duration(milliseconds: 500), (_) => _poll());
  }

  Future<void> _poll() async {
    if (_polling) return;
    _polling = true;
    try {
      final r = await HostBridge.guestPoll(_total);
      final chunk = (r['text'] ?? '').toString();
      final run = r['running'] == true;
      _total = (r['total'] as num?)?.toInt() ?? _total;
      var changed = false;
      if (r['reset'] == true) {
        console.clear();
        changed = true;
      }
      if (chunk.isNotEmpty) {
        for (final e in console.feed(chunk)) {
          _handle(e);
        }
        changed = true;
      }
      if (run && guestStarting) {
        guestStarting = false;
        changed = true;
      } else if (!run && guestStarting && DateTime.now().difference(_startedAt).inSeconds > 6) {
        guestStarting = false;
        changed = true;
      }
      if (run != linuxRunning) {
        linuxRunning = run;
        if (!run) guestStats = {};
        changed = true;
      }
      if (changed) notifyListeners();
    } catch (_) {
    } finally {
      _polling = false;
    }
  }

  void _handle(GuestEvent e) {
    if (e.kind == 'SU') {
      final p = e.body.split('|');
      if (p.length >= 3) {
        final result = p[0] == 'allowed' ? 'su allowed' : 'su denied';
        root.record(p[1], '$result: ${p.skip(2).join('|')}');
      }
    } else if (e.kind == 'STAT') {
      final m = <String, String>{};
      for (final kv in e.body.split('|')) {
        final i = kv.indexOf('=');
        if (i > 0) m[kv.substring(0, i)] = kv.substring(i + 1);
      }
      guestStats = m;
    }
  }

  /// Starts the Linux guest. Returns an error message, or null on success.
  Future<String?> startGuest() async {
    guestStarting = true;
    _startedAt = DateTime.now();
    _total = 0;
    console.clear();
    guestStats = {};
    notifyListeners();
    final r = await HostBridge.guestStart(allow: root.allowCsv());
    if (r['ok'] != true) {
      guestStarting = false;
      notifyListeners();
      return r['msg']?.toString() ?? 'Could not start guest';
    }
    return null;
  }

  Future<void> refresh() async {
    try {
      compat = CompatReport.fromMap(await HostBridge.hostInfo());
      guest = await HostBridge.guestStatus();
    } catch (e) {
      bootMessage = 'Host probe failed: $e';
    }
    notifyListeners();
  }

  Future<void> boot() async {
    final r = await HostBridge.bootGuest();
    bootMessage = r['reason']?.toString() ?? 'No response';
    notifyListeners();
  }

  Future<void> testQemu() async {
    qemuBusy = true;
    notifyListeners();
    try {
      final r = await HostBridge.qemuSmokeTest();
      qemuOutput = r['output']?.toString() ?? 'No output';
    } catch (e) {
      qemuOutput = 'Test failed: $e';
    }
    qemuBusy = false;
    notifyListeners();
  }

  Future<void> testKernel() async {
    kernelBusy = true;
    notifyListeners();
    try {
      final r = await HostBridge.kernelTest();
      kernelOutput = r['output']?.toString() ?? 'No output';
    } catch (e) {
      kernelOutput = 'Test failed: $e';
    }
    kernelBusy = false;
    notifyListeners();
  }

  void setLinuxRunning(bool v) {
    if (v == linuxRunning) return;
    linuxRunning = v;
    notifyListeners();
  }

  Future<void> setOnboarded() async {
    onboarded = true;
    await _p?.setBool('onboarded', true);
    notifyListeners();
  }

  Future<void> setShare({bool? clipboard, bool? files}) async {
    if (clipboard != null) {
      shareClipboard = clipboard;
      await _p?.setBool('shareClipboard', clipboard);
    }
    if (files != null) {
      shareFiles = files;
      await _p?.setBool('shareFiles', files);
    }
    notifyListeners();
  }

  Future<void> saveRoot() async {
    await _p?.setString('rootPolicy', jsonEncode(root.toJson()));
    notifyListeners();
  }
}
