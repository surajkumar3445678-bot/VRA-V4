import 'package:flutter/material.dart';

class VraColors {
  static const navy = Color(0xFF0A1128);
  static const card = Color(0xFF111B3A);
  static const cyan = Color(0xFF00E5FF);
  static const blue = Color(0xFF2979FF);
  static const warn = Color(0xFFFFB74D);
  static const bad = Color(0xFFFF5252);
  static const ok = Color(0xFF69F0AE);
  static const muted = Color(0xFF8FA3C8);
}

ThemeData vraTheme() => ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: VraColors.navy,
      colorScheme: const ColorScheme.dark(
          primary: VraColors.cyan, secondary: VraColors.blue, surface: VraColors.card),
      appBarTheme: const AppBarTheme(
          backgroundColor: VraColors.navy, elevation: 0, centerTitle: false),
      useMaterial3: true,
    );
