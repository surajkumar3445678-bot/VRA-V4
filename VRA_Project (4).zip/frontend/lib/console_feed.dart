/// Turns raw guest console output into display text and guest events.
/// Strips terminal escape codes. Lines like @@VRA_SU|...@@ and @@VRA_STAT|...@@ are
/// guest-to-host messages: they are removed from the text and returned as events.
class GuestEvent {
  final String kind;
  final String body;
  GuestEvent(this.kind, this.body);
}

class ConsoleFeed {
  final StringBuffer _text = StringBuffer();
  String _carry = '';
  static final RegExp _marker = RegExp(r'@@VRA_(SU|STAT)\|(.*?)@@');
  static final RegExp _ansi = RegExp(r'\x1B\[[0-9;?]*[A-Za-z]');

  String get text => _text.toString() + _carry;

  void clear() {
    _text.clear();
    _carry = '';
  }

  List<GuestEvent> feed(String chunk) {
    final events = <GuestEvent>[];
    final data = (_carry + chunk).replaceAll('\r', '').replaceAll(_ansi, '');
    final parts = data.split('\n');
    _carry = parts.removeLast();
    for (final line in parts) {
      var hadMarker = false;
      for (final m in _marker.allMatches(line)) {
        events.add(GuestEvent(m.group(1)!, m.group(2)!));
        hadMarker = true;
      }
      final shown = line.replaceAll(_marker, '');
      _text.write(shown);
      if (!hadMarker) _text.write('\n');
    }
    if (_text.length > 60000) {
      final t = _text.toString();
      _text.clear();
      _text.write(t.substring(t.length - 40000));
    }
    return events;
  }
}
