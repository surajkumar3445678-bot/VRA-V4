import 'package:flutter_test/flutter_test.dart';
import 'package:vra/console_feed.dart';

void main() {
  test('strips terminal escape codes', () {
    final f = ConsoleFeed();
    f.feed('a\x1B[6nb\n');
    expect(f.text, 'ab\n');
  });
  test('marker line becomes an event and is hidden', () {
    final f = ConsoleFeed();
    final e = f.feed('@@VRA_SU|allowed|app1|id@@\n');
    expect(e.length, 1);
    expect(e.first.kind, 'SU');
    expect(e.first.body, 'allowed|app1|id');
    expect(f.text, '');
  });
  test('marker after a prompt keeps the prompt', () {
    final f = ConsoleFeed();
    final e = f.feed('vra-guest # @@VRA_STAT|k=1@@\nhello\n');
    expect(e.length, 1);
    expect(e.first.kind, 'STAT');
    expect(f.text, 'vra-guest # hello\n');
  });
  test('partial lines are joined across chunks', () {
    final f = ConsoleFeed();
    f.feed('par');
    f.feed('tial\n');
    expect(f.text, 'partial\n');
  });
}
