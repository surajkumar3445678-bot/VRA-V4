import 'package:flutter_test/flutter_test.dart';
import 'package:vra/root_policy.dart';

void main() {
  test('unknown app is denied and logged', () {
    final p = RootPolicy();
    expect(p.request('a.b'), isFalse);
    expect(p.log.last.action, 'su denied');
  });
  test('grant then revoke', () {
    final p = RootPolicy()..grant('a.b');
    expect(p.request('a.b'), isTrue);
    p.revoke('a.b');
    expect(p.request('a.b'), isFalse);
  });
  test('json round trip keeps grants', () {
    final p = RootPolicy()..grant('a.b');
    final q = RootPolicy()..loadJson(p.toJson());
    expect(q.isGranted('a.b'), isTrue);
  });
  test('allowCsv lists only granted guest apps in order', () {
    final p = RootPolicy()..grant('app2')..grant('app1');
    expect(p.allowCsv(), 'app1,app2');
    p.revoke('app1');
    expect(p.allowCsv(), 'app2');
  });
}
