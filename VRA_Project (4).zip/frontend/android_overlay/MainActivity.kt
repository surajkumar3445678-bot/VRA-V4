package dev.vra.app

import dev.vra.host.GuestManager
import dev.vra.host.GuestSession
import dev.vra.host.HostInspector
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "dev.vra/host")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "hostInfo" -> result.success(HostInspector.hostInfo(this))
                    "guestStatus" -> result.success(GuestManager.status(this))
                    "bootGuest" -> result.success(GuestManager.boot(this))
                    "guestStart" -> Thread {
                        val r = GuestSession.start(this, call.argument<String>("allow") ?: "")
                        runOnUiThread { result.success(r) }
                    }.start()
                    "guestPoll" -> result.success(GuestSession.poll((call.argument<Number>("since") ?: 0).toLong()))
                    "guestSend" -> result.success(GuestSession.send(call.argument<String>("line") ?: ""))
                    "guestStop" -> {
                        GuestSession.stop()
                        result.success(true)
                    }
                    "kernelTest" -> Thread {
                        val r = GuestManager.kernelTest(this)
                        runOnUiThread { result.success(r) }
                    }.start()
                    "qemuSmokeTest" -> Thread {
                        val r = GuestManager.qemuSmokeTest(this)
                        runOnUiThread { result.success(r) }
                    }.start()
                    else -> result.notImplemented()
                }
            }
    }
}
