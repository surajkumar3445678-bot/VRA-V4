#!/bin/sh
# PID 1 of the VRA Linux guest. Runs entirely inside the guest (RAM only, no network).
export PATH=/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export TERM=dumb
mount -t proc proc /proc
mount -t sysfs sysfs /sys
mount -t devtmpfs devtmpfs /dev 2>/dev/null
mkdir -p /dev/pts /tmp /run /home /usr/local/bin
mount -t devpts devpts /dev/pts 2>/dev/null
mount -t tmpfs tmpfs /tmp
hostname vra-guest

# ---- guest-only su broker -------------------------------------------------
# Two guest "apps" (users). The host passes the granted list on the kernel command line
# as vra.su=app1,app2 . Each app can only write to its own request FIFO (mode 600),
# so the filesystem proves who is asking. Only the guest's root daemon runs commands.
SU_ALLOW=$(sed -n 's/.*vra\.su=\([^ ]*\).*/\1/p' /proc/cmdline)
adduser -D -u 10001 -h /home/app1 -s /bin/sh app1 >/dev/null 2>&1
adduser -D -u 10002 -h /home/app2 -s /bin/sh app2 >/dev/null 2>&1
mkdir -p /run/su
chmod 1777 /run/su
for u in app1 app2; do
  rm -f /run/su/req.$u
  mkfifo /run/su/req.$u
  chown $u /run/su/req.$u
  chmod 600 /run/su/req.$u
done

cat > /usr/local/bin/vsu <<'VSUEOF'
#!/bin/sh
# vsu -c "command": run a command as root in the guest, only if VRA's root manager allows this app.
[ "$1" = "-c" ] && shift
[ -z "$*" ] && { echo "usage: vsu -c command"; exit 2; }
u=$(id -un)
[ -p /run/su/req.$u ] || { echo "vsu: only guest app users can use vsu"; exit 2; }
r=/run/su/res.$$
rm -f $r
mkfifo $r || exit 1
echo "$r|$*" > /run/su/req.$u
cat $r
rm -f $r
VSUEOF
chmod 755 /usr/local/bin/vsu

susrv() {
  u=$1
  while true; do
    if read -r line < /run/su/req.$u; then
      res=${line%%|*}
      cmd=${line#*|}
      case "$res" in /run/su/res.*) ;; *) continue ;; esac
      [ -p "$res" ] || continue
      short=$(echo "$cmd" | cut -c1-80)
      case ",$SU_ALLOW," in
        *",$u,"*)
          echo "@@VRA_SU|allowed|$u|$short@@" > /dev/ttyAMA0
          sh -c "$cmd" > "$res" 2>&1 < /dev/null ;;
        *)
          echo "@@VRA_SU|denied|$u|$short@@" > /dev/ttyAMA0
          echo "su: permission denied (not granted in VRA root manager)" > "$res" ;;
      esac
    fi
  done
}
susrv app1 2>/dev/null &
susrv app2 2>/dev/null &

# ---- status lines for the VRA System monitor (guest -> host, one way) -------
statloop() {
  while true; do
    k=$(uname -r)
    cpus=$(grep -c '^processor' /proc/cpuinfo)
    mt=$(awk '/MemTotal/{print int($2/1024)}' /proc/meminfo)
    mf=$(awk '/MemAvailable/{print int($2/1024)}' /proc/meminfo)
    procs=$(ls -d /proc/[0-9]* 2>/dev/null | wc -l)
    net=$(ls /sys/class/net 2>/dev/null | grep -v '^lo$' | tr '\n' ',')
    up=$(cut -d. -f1 /proc/uptime)
    echo "@@VRA_STAT|k=$k|cpus=$cpus|memtotal=$mt|memfree=$mf|procs=$procs|net=${net:-none}|up=$up@@" > /dev/ttyAMA0
    sleep 5
  done
}
statloop 2>/dev/null &

echo
echo "=== VRA guest ready ==="
echo "Kernel: $(uname -r) (the guest's own kernel, not your phone's)"
echo "You are $(id -un) (uid $(id -u)) inside the guest only."
echo "Guest apps: app1, app2.  Try: su app1   then: vsu -c id"
echo "Type exit to shut the guest down."
echo
export PS1='vra-guest # '
setsid sh -c 'sh </dev/ttyAMA0 >/dev/ttyAMA0 2>&1'
echo "Shell ended. Powering off."
poweroff -f
